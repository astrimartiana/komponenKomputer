// PC COMPONENT — interaksi website

document.addEventListener("DOMContentLoaded", () => {
  const menuToggle = document.querySelector(".menu-toggle");
  const menu = document.querySelector(".nav-menu");
  const navLinks = document.querySelectorAll(".nav-menu a");

  // Menu navigasi untuk layar mobile
  if (menuToggle && menu) {
    menuToggle.addEventListener("click", () => {
      const isOpen = menu.classList.toggle("open");
      menuToggle.setAttribute("aria-expanded", String(isOpen));
      menuToggle.setAttribute(
        "aria-label",
        isOpen ? "Tutup navigasi" : "Buka navigasi"
      );
      menuToggle.textContent = isOpen ? "✕" : "☰";
    });

    // Tutup menu setelah salah satu tautan dipilih
    navLinks.forEach((link) => {
      link.addEventListener("click", () => {
        menu.classList.remove("open");
        menuToggle.setAttribute("aria-expanded", "false");
        menuToggle.setAttribute("aria-label", "Buka navigasi");
        menuToggle.textContent = "☰";
      });
    });

    // Tutup menu jika pengguna menekan tombol Escape
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        menu.classList.remove("open");
        menuToggle.setAttribute("aria-expanded", "false");
        menuToggle.setAttribute("aria-label", "Buka navigasi");
        menuToggle.textContent = "☰";
      }
    });
  }

  // Tandai menu sesuai bagian halaman yang sedang dilihat
  const sections = document.querySelectorAll("main section[id]");
  if ("IntersectionObserver" in window && sections.length && navLinks.length) {
    const sectionObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;

          navLinks.forEach((link) => {
            const isCurrent = link.getAttribute("href") === `#${entry.target.id}`;
            link.classList.toggle("active", isCurrent);
          });
        });
      },
      { rootMargin: "-35% 0px -55% 0px" }
    );

    sections.forEach((section) => sectionObserver.observe(section));
  }

  // Animasi elemen saat masuk ke area layar
  const revealElements = document.querySelectorAll(
    ".overview-card, .component-card, .software-card, .person-card"
  );

  if ("IntersectionObserver" in window) {
    const revealObserver = new IntersectionObserver(
      (entries, observer) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12 }
    );

    revealElements.forEach((element) => {
      element.classList.add("reveal");
      revealObserver.observe(element);
    });
  } else {
    revealElements.forEach((element) => element.classList.add("is-visible"));
  }

  // Tahun footer otomatis mengikuti tahun saat ini
  const copyright = document.querySelector(".footer small");
  if (copyright) {
    copyright.textContent = `© ${new Date().getFullYear()} PC Component. All rights reserved.`;
  }
});
